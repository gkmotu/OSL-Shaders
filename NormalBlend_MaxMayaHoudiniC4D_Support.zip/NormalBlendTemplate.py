import pymel.core as pm
from mtoa.ui.ae.shaderTemplate import ShaderAETemplate
# created by Rachid Hadj Abderrahmane#
# elrachyd@gmail.com#

class AENormalBlendTemplate(ShaderAETemplate):   
    def setup(self):
        #self.addSwatch()
        self.beginScrollLayout()

        self.beginLayout("Normal Blend Attributes", collapse=False)
        self.addControl("NormalA", label="Normal A")
        self.addControl("EnableNormalA", label="Enable")
        self.addControl("MixA", label="Mix")
        self.addSeparator()        
        self.addControl("NormalB", label="Normal B")
        self.addControl("EnableNormalB", label="Enable")
        self.addControl("MixB", label="Mix")
        self.addSeparator()
        self.addControl("FlipOrder", label="Flip Order")                
        self.endLayout()

        pm.mel.AEdependNodeTemplate(self.nodeName)
        self.addExtraControls()
        self.endScrollLayout()

