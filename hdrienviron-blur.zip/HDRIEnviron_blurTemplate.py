import pymel.core as pm
from mtoa.ui.ae.shaderTemplate import ShaderAETemplate
# created by Rachid Hadj Abderrahmane#
# elrachyd@gmail.com#

class AEHDRIEnviron_blurTemplate(ShaderAETemplate):
    def setup(self):
        #self.addSwatch()
        self.beginScrollLayout()

        self.beginLayout("HDRIEnviron blur Attributes", collapse=False)
        self.addControl("HDRI", label="Hdri")
        self.addControl("Rotation", label="Rotation")	
        self.addControl("Flip", label="Flip")
        self.addControl("TiltX", label="Tilt X")				
        self.addControl("TiltY", label="Tilt Y")
        self.addControl("Height", label="Height")
        self.endLayout()         
        self.addSeparator()
        self.beginLayout("Color Correction", collapse=False)        
        self.addControl("Exposure", label="Exposure")
        self.addControl("Tint", label="Tint")
        self.addControl("Contrast", label="Contrast")
        self.endLayout()         
        self.addSeparator()
        self.beginLayout("Projection", collapse=False)          
        self.addControl("Viewport", label="Viewport")
        self.addControl("GroundProjection", label="Ground Projection")
        self.addControl("GroundCenter", label="Ground Center")
        self.addControl("GroundRadius", label="Ground Radius")
        self.addControl("UseBackground", label="Use Background")
        self.addControl("Background", label="Background")
        self.addControl("BackgroundMultiplier", label="Background Multiplier")
        self.endLayout()         
        self.addSeparator()  
        self.beginLayout("Light blur", collapse=False)         
        self.addControl("AdditionalLight", label="Additional Light")
        self.addControl("AdditionalLightMul", label="Additional Light Mul")
        self.addControl("Blur", label="Blur")
        self.addControl("BlurAmount", label="Blur Amount")
        self.addControl("BlurSamples", label="Blur Samples")
        self.addControl("Clamp", label="Clamp")
        self.addControl("ClampStops", label="Clamp Stops")		
        self.addControl("blur", label="Blur")		

        self.endLayout()

        pm.mel.AEdependNodeTemplate(self.nodeName)
        self.addExtraControls()
        self.endScrollLayout()

